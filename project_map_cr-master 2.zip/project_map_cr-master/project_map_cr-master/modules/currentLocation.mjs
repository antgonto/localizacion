import { generateMarker, marker, generateCircle, circle} from '../js/index.js'
import { getFormatedCoord } from '../modules/coordinates.mjs';

// Set marker on map
function setMarker(lat, lng, map) {
    let msg = `Localizacion actual: <br> ${getFormatedCoord('DD', lat, lng)}`;

    if (marker === undefined){
        generateMarker(lat, lng, msg);
    }else {
        map.removeLayer(marker);
        generateMarker(lat, lng, msg);
    };
};

// Set circle on map
function setCircle(latlng, radius, map) {
    if (circle === undefined) {
        generateCircle(latlng, radius, map);
    }else {
        map.removeLayer(circle);
        generateCircle(latlng, radius, map);
    };
};

// Gets current location
function getCurrentLocation(el, map) {
    const radius = el.accuracy, 
          lat = el.latlng.lat,
          lng = el.latlng.lng;

    setMarker(lat, lng, map);

    setCircle(el.latlng, radius, map);
};

function onGetLocationError(el) {
    alert(el.message);
};

export { getCurrentLocation, onGetLocationError };