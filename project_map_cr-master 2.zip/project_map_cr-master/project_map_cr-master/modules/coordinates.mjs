import { els } from '../modules/doms.mjs'

// Degree to Minute Converter
const minutes = (degree) => {
    const degreePositive = Math.abs(degree);
    return ((degreePositive - Math.trunc(degreePositive))*60);
};
// Degree to Minute Seconds
const seconds = (degree) => {
    const degreePositive = Math.abs(degree);
    return (degreePositive - Math.trunc(degreePositive) - Math.trunc(minutes(degreePositive)) / 60) * 3600;
};

// Decimal Degree Format
const displayDDCordinates = (lat, lng) => {
    return `${lat.toFixed(3)}° N ${lng.toFixed(3)}° O`
};

// Decimal Degree Minute Format
const displayDDMCordinates = (lat, lng) => {
    return `${Math.trunc(lat)}° ${minutes(lat).toFixed(3)}' N ${Math.trunc(lng)}° ${minutes(lng).toFixed(3)}' O`;
};

// Degree Minute Second Format
const displayDMSCordinates = (lat, lng) => {
    return `${Math.trunc(lat)}° ${Math.trunc(minutes(lat))}' ${seconds(lat).toFixed(1)}" N ${Math.trunc(lng)}° ${Math.trunc(minutes(lng))}' ${seconds(lng).toFixed(1)}" O`;
};

// Button selected function
let lastActive = els.btnChecked[0];
function isActive(btn) {
    if(!btn.classList.contains('active')){
        lastActive.classList.remove('active');
        lastActive = btn;
        btn.classList.add('active');
    }else{
        lastActive = btn;
    };
    return btn.textContent;
};

// Button value saver
let getFormatBtnValue = 'DD';

els.btnChecked.forEach(btn => {
    btn.addEventListener('click', () => {
        getFormatBtnValue = isActive(btn);
    });
});

// Exported format coordinates function
function getFormatedCoord (formatValue, lat, lng) {
    let coord;
    switch(formatValue){
        case 'DD':
            coord = displayDDCordinates(lat, lng);
            break;
        case 'DDM':
            coord = displayDDMCordinates(lat, lng);
            break;
        case 'DMS':
            coord = displayDMSCordinates(lat, lng);
            break;
    };
    return coord;
};

export {getFormatBtnValue, getFormatedCoord}