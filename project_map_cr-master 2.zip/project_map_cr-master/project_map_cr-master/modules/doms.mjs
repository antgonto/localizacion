/* DOM Elements */
export const els = {
    infoDisplay: document.getElementById('info-display'),
    coordinatesDisplay: document.getElementById('coordinates-display'),
    btnChecked: document.querySelectorAll('.formatBtn'),
    getMyLoc: document.getElementById('myLocBtn'),
    infoLoc: document.getElementById('info-myLoc'),
    btnArea: document.getElementById('areaBtn')
};
