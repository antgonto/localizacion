import { els } from '../modules/doms.mjs'
import { getFormatedCoord, getFormatBtnValue } from '../modules/coordinates.mjs';
import { getCurrentLocation, onGetLocationError } from '../modules/currentLocation.mjs';

/* Base Map & Config */
let latitud = 9.933;
let longitud = -84.087;

const map = L.map('map') // Base map image
             .setView([latitud, longitud], 8); // Map view first loaded

/* Map types:
** Topographic
** Imagery
*/
L.esri.basemapLayer('Topographic').addTo(map);


/* ArcGIS CR Data */
// URL ArcGIS Service
const arcgisURL = `https://services.arcgis.com/LjCtRQt1uf8M6LGR/arcgis/rest/services/Distritos_CR/FeatureServer/0`;

// Change map layer style (IF necessary)
let colorizeLayerStyle = (clr, fClr, wgt) => {
    return {color: clr, fillColor: fClr, weight: wgt}
};

// Costa Rican map with information
const locationCR =
    L.esri.featureLayer({
        url: arcgisURL,
        style:  () => {return colorizeLayerStyle('#363636', 'rgba(255, 255, 255, 0.5)', 0.1)},
        crossOrigin: null
    });

// Adds CR layer to base map
locationCR.addTo(map);


///-----------------------------------/
/* SHOW PROVINCIA, CANTON, DISTRITO */
///---------------------------------/
function layer(el) {
    return {
        prov: el.layer.feature.properties.NOM_PROV,
        cant: el.layer.feature.properties.NOM_CANT,
        dist: el.layer.feature.properties.NOM_DIST
    }
};

locationCR.on('mouseover', (el) => {
    els.infoDisplay.innerHTML = `${layer(el).prov}, ${layer(el).cant}, ${layer(el).dist}`;
});
locationCR.on('mouseout', () => {
    els.infoDisplay.innerHTML = '';
});


///-----------------------------------/
/* DISPLAY MOUSE COORDINATES        */
///---------------------------------/
map.addEventListener('mousemove', (el) => {
    els.coordinatesDisplay.innerHTML = getFormatedCoord(getFormatBtnValue, el.latlng.lat, el.latlng.lng);
});


///-----------------------------------/
/* GET CURRENT LOCATION             */
///---------------------------------/
els.getMyLoc.addEventListener('click', () => {
    map.locate({setView: true, maxZoom: 16}); // add "watch: true" for auto update location
    map.on('locationfound', (el) => getCurrentLocation(el, map));
    map.on('locationerror', onGetLocationError);
});



let marker;
function generateMarker(lat, lng, msg) {
    marker = new  L.marker([lat, lng]) // Marker position
                    .bindPopup(msg) // Marker information popup
                    .togglePopup()
                    .addTo(map);

    return marker;
};

let circle;
function generateCircle(latlng, radius, map) {
    circle = new L.circle(latlng, radius).addTo(map);

    return circle;
};

///-----------------------------------/
/* DRAW FUNCTION            */
///---------------------------------/
var poly;

 var drawnItems = new L.FeatureGroup();
        map.addLayer(drawnItems);

        var drawControl = new L.Control.Draw({
            edit: {
                featureGroup: drawnItems
            }
        });
        map.addControl(drawControl);

        map.on('draw:created', function (e) {
            var type = e.layerType,
                layer = e.layer;
            drawnItems.addLayer(layer);
        });

map.on(L.Draw.Event.CREATED, function (e) {
    var layer = e.layer;
    drawnItems.addLayer(layer);
    console.log(layer.getLatLngs());
    poly = layer;
});



function isMarkerInsidePolygon(marker, poly) {
      
               var inside = false;
               var x = marker.getLatLng().lat, y = marker.getLatLng().lng;
               for (var ii=0;ii<poly.getLatLngs().length;ii++){
                   var polyPoints = poly.getLatLngs()[ii];
             
                   for (var i = 0, j = polyPoints.length - 1; i < polyPoints.length; j = i++) {
                       var xi = polyPoints[i].lat, yi = polyPoints[i].lng;
                       var xj = polyPoints[j].lat, yj = polyPoints[j].lng;
                     
                       var intersect = ((yi > y) != (yj > y))
                           && (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
                       if (intersect) inside = !inside;
                   }
               }
               if (inside == true){
                alert("SI ESTOY EN EL ÁREA DE COBERTURA");
               }else{
                alert("NO ESTOY EN EL ÁREA DE COBERTURA");
               }
              
               return inside;
               
};

els.btnArea.addEventListener('click', () => {
  isMarkerInsidePolygon(marker, poly);
});




export {marker, generateMarker, circle, generateCircle};
